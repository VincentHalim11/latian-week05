﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        int angka = 0;
        bool cek = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
            

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            int locationx = 50;
            int locationy = 70;
            int count = 1;
            int banyak = Convert.ToInt32(textBox1.Text);
            
            
            for(int i = 1; i <= banyak; i++)
            {
                Button buttonaru = new Button();
                buttonaru.Size = new Size(30, 20);
                buttonaru.Location = new Point(locationx, locationy);
                buttonaru.Text = (count).ToString();
                buttonaru.Click += new EventHandler(buttonaruClicksEvent);
                this.Controls.Add(buttonaru);
                locationx += 50;
                count++;
                if(count %2 == 0)
                {
                    buttonaru.Tag = "even";
                }
                else if (count % 2 != 0 )
                {
                    buttonaru.Tag = "odd";
                }
                if(i % 5 ==0)
                {
                    locationx = 50;
                    locationy += 30;
                }
                    
            }
          
        }

        public void buttonaruClicksEvent(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            MessageBox.Show(btn.Text + " is " + btn.Tag);
        }
    }
}
